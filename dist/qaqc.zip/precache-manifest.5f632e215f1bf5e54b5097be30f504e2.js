self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "601e4d03b21208ecea9c0ab207acb51f",
    "url": "/apple-icon.png"
  },
  {
    "revision": "b75377b5cf0b0af89105",
    "url": "/css/app.a789e3cb.css"
  },
  {
    "revision": "df4b775fecdf80b042dd",
    "url": "/css/chunk-vendors.ac7370d1.css"
  },
  {
    "revision": "601e4d03b21208ecea9c0ab207acb51f",
    "url": "/favicon.png"
  },
  {
    "revision": "32103624b1dd883d3d18dbcb1e0e8af6",
    "url": "/img/sidebar-2.32103624.jpg"
  },
  {
    "revision": "ed93f27a8793d2a1328c10a6ffd1a921",
    "url": "/img/sundry-logo.ed93f27a.png"
  },
  {
    "revision": "ed93f27a8793d2a1328c10a6ffd1a921",
    "url": "/img/sundry-logo.png"
  },
  {
    "revision": "d4844db3c0b5c417c9a35d4ce61ce400",
    "url": "/index.html"
  },
  {
    "revision": "b75377b5cf0b0af89105",
    "url": "/js/app.d570d8d5.js"
  },
  {
    "revision": "df4b775fecdf80b042dd",
    "url": "/js/chunk-vendors.26ffcfa0.js"
  },
  {
    "revision": "77e0dd6e0cef24d18b237015ef5eca59",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);