self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "601e4d03b21208ecea9c0ab207acb51f",
    "url": "/apple-icon.png"
  },
  {
    "revision": "795c61169fa7f2f9a7d3",
    "url": "/css/app.692fd2d9.css"
  },
  {
    "revision": "df4b775fecdf80b042dd",
    "url": "/css/chunk-vendors.ac7370d1.css"
  },
  {
    "revision": "601e4d03b21208ecea9c0ab207acb51f",
    "url": "/favicon.png"
  },
  {
    "revision": "32103624b1dd883d3d18dbcb1e0e8af6",
    "url": "/img/sidebar-2.32103624.jpg"
  },
  {
    "revision": "ed93f27a8793d2a1328c10a6ffd1a921",
    "url": "/img/sundry-logo.ed93f27a.png"
  },
  {
    "revision": "ed93f27a8793d2a1328c10a6ffd1a921",
    "url": "/img/sundry-logo.png"
  },
  {
    "revision": "906aed00158c6aff53f46a1388ae66c4",
    "url": "/index.html"
  },
  {
    "revision": "795c61169fa7f2f9a7d3",
    "url": "/js/app.e65e1075.js"
  },
  {
    "revision": "df4b775fecdf80b042dd",
    "url": "/js/chunk-vendors.26ffcfa0.js"
  },
  {
    "revision": "77e0dd6e0cef24d18b237015ef5eca59",
    "url": "/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
]);