self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "601e4d03b21208ecea9c0ab207acb51f",
    "url": "/apple-icon.png"
  },
  {
    "revision": "bf4b1c77c54f7b00e02b",
    "url": "/css/app.90a0854f.css"
  },
  {
    "revision": "df4b775fecdf80b042dd",
    "url": "/css/chunk-vendors.ac7370d1.css"
  },
  {
    "revision": "601e4d03b21208ecea9c0ab207acb51f",
    "url": "/favicon.png"
  },
  {
    "revision": "32103624b1dd883d3d18dbcb1e0e8af6",
    "url": "/img/sidebar-2.32103624.jpg"
  },
  {
    "revision": "ed93f27a8793d2a1328c10a6ffd1a921",
    "url": "/img/sundry-logo.ed93f27a.png"
  },
  {
    "revision": "ed93f27a8793d2a1328c10a6ffd1a921",
    "url": "/img/sundry-logo.png"
  },
  {
    "revision": "1e60eaecee7769a3e185427e6028368b",
    "url": "/index.html"
  },
  {
    "revision": "bf4b1c77c54f7b00e02b",
    "url": "/js/app.398083f8.js"
  },
  {
    "revision": "df4b775fecdf80b042dd",
    "url": "/js/chunk-vendors.26ffcfa0.js"
  },
  {
    "revision": "77e0dd6e0cef24d18b237015ef5eca59",
    "url": "/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
]);